# Google VR SDK for Android

Enables Daydream and Cardboard app development on Android.

Copyright (c) 2016 Google Inc. All rights reserved.

For updates, known issues, and upgrade instructions, see the
[release-notes](//github.com/googlevr/gvr-android-sdk/releases).

For first time users, see the
[Get Started with Google VR on Android](//developers.google.com/vr/android/get-started)
guide.

Please note, we do not accept pull requests.
